package Exceptoins;

public class NotExistDocumentException extends Exception{

}
