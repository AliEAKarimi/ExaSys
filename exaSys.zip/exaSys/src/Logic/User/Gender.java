package Logic.User;

import java.io.Serializable;

public enum Gender implements Serializable {
    MALE, FEMALE
}
