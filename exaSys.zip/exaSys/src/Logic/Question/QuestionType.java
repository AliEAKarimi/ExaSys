package Logic.Question;

import java.io.Serializable;

public enum QuestionType implements Serializable {
    DESCRIPTIVE, TESTY, TRUE_FALSE;
}
